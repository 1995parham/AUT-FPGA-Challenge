#include "Board.hpp"

#include <iostream>
#include <cstdlib>
#include <sstream>
#include <iomanip>
#include <utility>
#include <cmath>

#include "Placement.hpp"
#include "Marble.hpp"
#include "Options.hpp"

#include "util.h"

namespace Connect6 {

Board::Board( int row, int column ) 
  : row_(row), column_(column), map_(NULL), 
    score_table_h_(NULL), score_table_v_(NULL),
    score_table_a_(NULL), score_table_a2_(NULL) {

  map_ = new std::map<int, DiskColor>();
  //log_ = new std::vector<Placement>();

  score_table_h_ = new int[row*column];
  score_table_v_ = new int[row*column];
  score_table_a_ = new int[row*column];
  score_table_a2_ = new int[row*column];
}

bool Board::put(DiskColor disk, int row, int column) {
  if ( row < 1 || column < 1 || row > row_ || column > column_ ) {
    return false;
  } else {
    int index = getIndex(row, column);
    if (map_->find(index) != map_->end()) {
      return false;
    } else {
      map_->insert(std::make_pair(index, disk));
      return true;
    }
  }
}

bool Board::put(const Placement *p) {
  return put (p->getMarble().toDiskColor(), 
	      p->getRow(),
	      p->getColumn()
  );
}

DiskColor Board::judge() {
  for(int y=1; y<=row_; ++y) {
    for(int x=1; x<=column_; ++x) {
      int index = getIndex(x, y);
      DiskColor d = getDisk(index);
      
      // �������Υ�����
      int score_h = updateScore(d, getIndex(x-1, y), index, score_table_h_);

      // �������Υ�����
      int score_v = updateScore(d, getIndex(x, y-1), index, score_table_v_);
      
      // �Ф������Υ�����
      int score_a = updateScore(d, getIndex(x-1, y-1), index, score_table_a_);

      int score_a2 = updateScore(d, getIndex(x+1, y-1), index, score_table_a2_);

      // ���祹����
      int score = std::max(std::max(score_v, score_h), std::max(score_a, score_a2));

      if (score >= 6) return d;
    }
  }  

  return empty;
}

void Board::printBoard() {
  std::ostringstream oss;
  std::map<int, DiskColor>::iterator it;

  oss << "   ";
  for(int x=1; x<=column_; x++) {
    // ����Ϥ��ޤ�ط��ʤ����ɡ����פ��Τ����ɲ�
    oss << std::setw(2) << std::setfill('0') << x << " "; 
  }
  oss << std::endl;
  
  for(int y=1; y<=row_; ++y) {
    oss << std::setw(2) << std::setfill('0') << y << "|";
    for(int x=1; x<=column_; ++x) {
      
      DiskColor disk = getDisk(getIndex(y, x));

      if( disk == empty) {
	oss <<  "  |";
      } else if (disk == black) {
	oss <<  " *|";
      } else if (disk == white) {
	oss <<  " o|";
      }
      
    }
    oss << std::endl;
  }
  std::cout << oss.str();
}

int Board::getIndex(int row, int column) const {
  if ( row < 1 || column < 1 || row > row_ || column > column_) {
    return -1;
  } else {
    return column_ * (row-1) + (column-1);
  }
}

int Board::getRow(int index) const {
  return index / column_ + 1;
}

int Board::getColumn(int index) const {
  return index % column_ + 1;
}

DiskColor Board::getDisk(int index) const {
  DiskColor disk = empty;
  std::map<int, DiskColor>::iterator it = map_->find(index);
  if (map_->find(index) != map_->end()) disk = it->second;

  return disk;
}

int Board::updateScore(DiskColor d,
		       int index_prev,
		       int index_current,
		       int *table) {
  int score = d;
  
  if( index_prev >= 0 ) {
    int score_prev = table[index_prev];
    if (score_prev * d > 0) {
      score =  score_prev + d;
    } 
  }

  table[index_current] = score;

  return std::abs(score);
}

Board::~Board() {
  if (map_ != NULL) delete map_;
  if (score_table_h_ != NULL) delete [] score_table_h_;
  if (score_table_v_ != NULL) delete [] score_table_v_;
  if (score_table_a_ != NULL) delete [] score_table_a_;
  if (score_table_a2_ != NULL) delete [] score_table_a2_;
}

};
