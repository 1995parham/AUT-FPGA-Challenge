#ifndef GAMERESULTWIN_HPP
#define GAMERESULTWIN_HPP

#include "IGameResult.hpp"

#include <string>

namespace Connect6 {

class IPlayer;

class GameResultWin : public IGameResult {
public:
  GameResultWin(const IPlayer& player);

  ~GameResultWin();

private:
  std::string msg_;
  std::string toString_();
};

};

#endif
