#ifndef GAMERESULTTURNOVER_HPP
#define GAMERESULTTURNOVER_HPP

#include "IGameResult.hpp"

namespace Connect6 {

class GameResultTurnover : public IGameResult {
public:
  GameResultTurnover();

  ~GameResultTurnover();

private:
  std::string toString_();

};
};

#endif
