#include "GameResultTimeover.hpp"

#include "IPlayer.hpp"

#include <sstream>

namespace Connect6 {

GameResultTimeover::GameResultTimeover(const IPlayer& player, double limit)
  : msg_() {
  std::ostringstream oss;
  
  oss << player.getName()
      << " has now competed a move in "
      << limit
      << " second(s).";

  msg_ = oss.str();
}

std::string GameResultTimeover::toString_() {
  return msg_;
}

GameResultTimeover::~GameResultTimeover() {

}

};
