#ifndef UTIL_H
#define UTIL_H

// この値は非常に重要なので安易に変えるべからず
enum DiskColor{
  black = 1,
  white = -1,
  empty = 0
};

#endif
