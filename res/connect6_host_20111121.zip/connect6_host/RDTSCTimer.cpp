#include "RDTSCTimer.hpp"

#include "timeMeasure_RDTSC.h"

namespace Connect6 {

RDTSCTimer::RDTSCTimer():start_(), cpu_freq_() {
  cpu_freq_ = obtain_cpu_freq(20000, 10);
}

void RDTSCTimer::reset() {
  start_ = get_rdtsc();
}

double RDTSCTimer::time() {
  return calcSecFromCycles(start_, get_rdtsc(), cpu_freq_);
}

double RDTSCTimer::frequency() const {
  return cpu_freq_;
}

RDTSCTimer::~RDTSCTimer() {

}

};
