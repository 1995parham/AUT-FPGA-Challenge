#ifndef CONNECT6_HPP
#define CONNECT6_HPP

/***
 * Connect6に必要なすべてのヘッダをインクルードする
 */

#include "Options.hpp"

#include "IPlayer.hpp"
#include "PlayerFactory.hpp"

#include "Marble.hpp"
#include "Board.hpp"
#include "Placement.hpp"

#include "PlacementQueue.hpp"

#include "IGameResult.hpp"
#include "GameResultWin.hpp"
#include "GameResultTimeover.hpp"
#include "GameResultTurnover.hpp"
#include "GameResultStop.hpp"
#include "GameResultInvalidPlacement.hpp"

#endif
