#include "util.h"

#include "Options.hpp"

using namespace std;

void setup_com_port(int fd) {
  struct termios newtio;
  memset(&newtio, 0,sizeof(newtio));

  newtio.c_cflag= (B115200 | CS8 | CLOCAL | CREAD);
   
  newtio.c_iflag=IGNPAR;         
  newtio.c_oflag=0;              
  newtio.c_lflag=0;              

  tcflush(fd,TCIFLUSH);           /* �|�[�g�̃N���A */
  tcsetattr(fd, TCSANOW, &newtio);
  return;
}

int select_com_port(int &argc, char **argv)
{
  string com_port;
  int i, nargc;
  bool cmd_line_port_set = false;
  
  for(i=0;i<argc; i++){
    if((strcmp(argv[i],"-port")==0) && ((i+1) < argc)){
      com_port = argv[i+1];
      cmd_line_port_set = true;
      nargc = i;
    }
  }
  if( !cmd_line_port_set ){
    cout << "Serial Port Mode\nTo set up serial port, please enter serial port name...\n";
    cin >> com_port;
  }else{
    argc = nargc;
    cout << com_port << "\n";
  }
  
  int opt = Connect6::Options::instance()->getPortOpenOption();
  return open_com_port(com_port, opt);
}

int open_com_port(std::string com_port, int open_opt) {
  int permiss = ((open_opt & O_WRONLY)!= 0) ? (S_IREAD | S_IWRITE) : 0;
  int port = open(com_port.c_str(), open_opt, permiss);
  while(port < 0) // if open is unsucessful keep trying until the user specifies a good port
  {
    cout << "Unable to open port \"" << com_port << "\", try again, should be: (windows) /dev/comx or (linux) /dev/ttyx ?\n";
    cin >> com_port;
    port = open(com_port.c_str(), open_opt, permiss);
  }
  setup_com_port(port);
    
  cout << "COM port has been set up at a baud rate of 115200\n";
  return port;
}

double getcputime()
{
  struct timeval tv;
  //clock_gettime(CLOCK_REALTIME,&tv);
  gettimeofday(&tv,NULL);
  return tv.tv_sec + (double)tv.tv_usec*1e-6;
}
