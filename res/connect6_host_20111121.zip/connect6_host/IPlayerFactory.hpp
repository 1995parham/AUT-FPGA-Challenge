#ifndef IPLAYERFACTORY_HPP
#define IPLAYERFACTORY_HPP

#include <map>
#include <string>

namespace Connect6 {

class Marble;
class IPlayer;

/**
 * 各IPlayerの派生クラスを作成するファクトリークラスのインタフェース．
 */
class IPlayerFactory {

public:
  IPlayerFactory();

  IPlayer* create(const std::map<std::string, std::string>& arg, 
		  const Marble& marble);

  virtual ~IPlayerFactory();

protected:

  virtual IPlayer* create_(const std::map<std::string, std::string>& arg,
			   const std::string& name,
			   const Marble& marble,
			   double timeout) = 0;

  int toInteger(const std::string& str);
  
};

};

#endif
