#include "HumanCUIPlayerFactory.hpp"

#include "HumanCUIPlayer.hpp"

namespace Connect6 {

HumanCUIPlayerFactory::HumanCUIPlayerFactory() : IPlayerFactory() {

}

IPlayer* HumanCUIPlayerFactory::create_
(
 const std::map<std::string, std::string>& arg,
 const std::string& name,
 const Marble& marble,
 double timeout) {

  
  const std::string name_ 
    = (name.size() == 0) ? "Human_" + marble.toString() : name;
    
  return new HumanCUIPlayer(name_, marble, timeout);
}

HumanCUIPlayerFactory::~HumanCUIPlayerFactory() {

}

};
