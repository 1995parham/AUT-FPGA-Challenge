#ifndef GAMERESULTTIMEOVER_HPP
#define GAMERESULTTIMEOVER_HPP

#include "IGameResult.hpp"

#include <string>

namespace Connect6 {

class IPlayer;

class GameResultTimeover : public IGameResult {
public:
  GameResultTimeover(const IPlayer& player, double limit);

  ~GameResultTimeover();

private:
  std::string msg_;
  std::string toString_();

};

};

#endif
