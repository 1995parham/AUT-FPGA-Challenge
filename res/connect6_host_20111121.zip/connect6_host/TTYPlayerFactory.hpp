#ifndef TTYPLAYERFACTORY_HPP
#define TTYPLAYERFACTORY_HPP

#include "IPlayerFactory.hpp"

namespace Connect6 {

/**
 * TTYPlayerクラスのインスタンスを生成するファクトリークラス
 */
class TTYPlayerFactory : public IPlayerFactory {

public:
  TTYPlayerFactory();

  ~TTYPlayerFactory();

protected:
  IPlayer* create_(const std::map<std::string, std::string>& arg,
		   const std::string& name,
		   const Marble& marble,
		   double timeout);

};

};

#endif
