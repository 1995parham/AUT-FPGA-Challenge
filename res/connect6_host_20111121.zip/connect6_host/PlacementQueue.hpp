#ifndef PLACEMENTQUEUE_HPP
#define PLACEMENTQUEUE_HPP

#include <queue>
#include <pthread.h>

namespace Connect6 {

class IPlayer;
class Placement;
class RDTSCTimer;

class PlacementQueue {

public:
  PlacementQueue(IPlayer *p1, IPlayer *p2);

  /**
   * プレイヤからのPlacementの取得を開始する
   */
  void start();

  /**
   * Placementの取得を一時停止する．スレッドは待機．
   */
  void stop();

  /**
   * Placementの取得を終了する．スレッドも終了させる．
   */
  void finish();

  /**
   * キューが空だったら真を返す
   */
  bool empty();

  /**
   * キューに入っている手の数を返す
   */
  size_t size();
  
  /**
   * キューの先頭要素を返す
   */
  Placement* front();
  
  /**
   * キューの末尾要素を返す
   */
  Placement* back();
  
  /**
   * キューの先頭をポップする
   */
  void pop();

  /**
   * キューの末尾にプッシュする
   */
  void push(Placement* p);

  ~PlacementQueue();

private:
  IPlayer *player_current_;
  IPlayer *player_next_;
  std::queue<Placement*> *queue_;
  RDTSCTimer *timer_;
  
  bool flag_busy_;

  pthread_mutex_t mutex_q_;
  pthread_mutex_t mutex_status_;
  pthread_t thread_;

  void init();

  static void* startThread(void *obj);
  
  void loop();
  
};

};

#endif
