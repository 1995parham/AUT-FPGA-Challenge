#include <stdio.h>
#include <unistd.h>
#include <time.h>

int main(char argv, char *argc[]) {

	char buf[512];
	struct timespec timesleep;

	timesleep.tv_sec = 0;
	timesleep.tv_nsec = 500000000;

	FILE *fp = NULL;
	//fp = fopen("connect6_SW2.log", "rt");
	fp = fopen("connect6_SW.log", "rt");

	while (fgets(buf, 512, fp) != NULL) {

		if(buf[0] == '\n') {
			fflush(stdout);
			nanosleep(&timesleep, NULL);
		}

		printf("%s", buf);
	}

	return 0;
}
