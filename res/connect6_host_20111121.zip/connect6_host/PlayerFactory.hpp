#ifndef PLAYERFACTORY_HPP
#define PLAYERFACTORY_HPP

#include <string>
#include <vector>

namespace Connect6 {

class IPlayer;
class Marble;

class PlayerFactory {

public:
  PlayerFactory(){};

  static IPlayer* create(const std::string& arg, const Marble& marble) ;

  ~PlayerFactory(){};

private:
  
  /**
 * strをdelimitaで区切って各フィールドをbufに追加する．
 */
  static void split
  (
   const std::string& str, 
   const char delimita, 
   std::vector<std::string> *buf
  );

};

};

#endif
