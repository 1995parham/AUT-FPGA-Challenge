#include "IPlayerFactory.hpp"

#include <sstream>
#include <map>
#include <string>

#include "Marble.hpp"

namespace Connect6 {

IPlayerFactory::IPlayerFactory() {

}

IPlayer* IPlayerFactory::create
(
 const std::map<std::string, std::string>& arg, 
 const Marble& marble
) {
  std::map<std::string, std::string>::const_iterator it;
  
  std::string name;
  it = arg.find("name");
  if ( it != arg.end()) {
    name = it->second;
  } else {
    name = "Player" + marble.toString();
  }
  
  double timeout;
  if ( (it = arg.find("timeout")) != arg.end()) {
    timeout = toInteger(it->second);
  } else {
    timeout = 1;
  }

  return create_(arg, name, marble, timeout);
  
}

int IPlayerFactory::toInteger(const std::string& str) {
  int value;
  
  std::istringstream iss(str);
  
  iss >> value;
  return value;
}

IPlayerFactory::~IPlayerFactory() {

}

};
