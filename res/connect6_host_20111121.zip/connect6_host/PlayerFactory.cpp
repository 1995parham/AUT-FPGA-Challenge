#include "PlayerFactory.hpp"

#include <string>
#include <vector>
#include <map>

#include "Marble.hpp"

#include "IPlayer.hpp"
#include "IPlayerFactory.hpp"

#include "TTYPlayer.hpp"
#include "TTYPlayerFactory.hpp"

#include "HumanCUIPlayer.hpp"
#include "HumanCUIPlayerFactory.hpp"

namespace Connect6 {

IPlayer* PlayerFactory::create(const std::string& arg, const Marble& marble) {
  std::vector<std::string> splited_arg;
  std::map<std::string, std::string> fields;

  IPlayerFactory *ipf = NULL;
  
  split(arg, ':', &splited_arg);
  
  if(splited_arg.size() < 3) return NULL;
  
  fields.insert( make_pair("type", splited_arg.at(0)) );
  fields.insert( make_pair("name", splited_arg.at(1)) );
  fields.insert( make_pair("timeout", splited_arg.at(2)) );
  
  if(splited_arg.at(0) == "tty") {
    if(splited_arg.size() == 4) {
      fields.insert( make_pair("readport", splited_arg.at(3)) );
      fields.insert( make_pair("writeport", splited_arg.at(3)) );
    } else if(splited_arg.size() >= 5) {
      fields.insert( make_pair("readport", splited_arg.at(3)) );
      fields.insert( make_pair("writeport", splited_arg.at(4)) );
    }
    ipf = new TTYPlayerFactory();
  }  else if (splited_arg.at(0) == "humancui") {
    ipf = new HumanCUIPlayerFactory();
  }
  
  if(ipf != NULL) {
    return ipf->create(fields, marble);
  } else {
    return NULL;
  }  
}

void PlayerFactory::split
(
 const std::string& str,
 const char delimita,
 std::vector<std::string> *buf
) {
  if (buf == NULL) return;

  std::string temp = str;
  
  while( temp.size() > 0) {
    std::string::size_type pos = temp.find(delimita);
    if(pos == std::string::npos) {
      buf->push_back(temp);
      temp.erase();
    } else {
      buf->push_back(temp.substr(0, pos));
      temp = temp.substr(pos+1);
    }
  }
}	   

};

