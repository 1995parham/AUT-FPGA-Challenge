#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <time.h>
#include <fcntl.h>

#include <glib.h>
#include <gtk/gtk.h>
#include <gtk/gtkgl.h>
#include <gdk/gdkkeysyms.h>
#include <GL/gl.h>
#include <cairo.h>

#define BOARD_SIZE	19	// Board size
#define STEP		30	// Cell pitch
#define X_OFFSET	40
#define Y_OFFSET	40

#define GL_RESOLUTION_X 630
#define GL_RESOLUTION_Y 670

// ===== Fonts =====
#define FONT_SIZE 	17.0
#define FONT_FAMILY	"Arial"

// ===== Colors (RGB) =====
#define RGB_FONT	0.0, 0.0, 0.0
#define RGB_CELLEDGE	0.45, 0.29, 0.14
#define RGB_CELLFILL	0.96, 0.57, 0.11 
#define RGB_BGCOLOR0	0.0, 0.75, 0.0
#define RGB_BGCOLOR1	0.0, 0.35, 0.0

enum STATE {
	ST_EMPTY = 0,
	ST_BLACK = 1,
	ST_WHITE = -1,
};

enum RENDER_MODE {
	RENDER_OGL_DIRECT = 0,
	RENDER_OGL_INDIRECT,
	RENDER_SW,
};

typedef struct _BOARD_STATE {
	enum STATE cell[BOARD_SIZE][BOARD_SIZE];
} BOARD_STATE;

//=============================================================================
// Global
//=============================================================================
typedef struct _GLOBAL {

	pthread_t pt;
	bool thread_end;

	int default_height, default_width;

	int hist_max, hist_cur;

	enum RENDER_MODE render_mode;

	cairo_surface_t *surface;
	unsigned char *surface_data;
	GLuint texture;

	GList *gl_history;

	// Gtk Widgets
	GtkWidget *window;
	GtkWidget *vbox1;

	GtkWidget *hbox1;
	GtkWidget *button1;
	GtkWidget *button2;
	GtkWidget *label1;

	GtkWidget *align1;
	GtkWidget *draw1;


	// =======================================================
	// Widget Hieralchy
	// =======================================================
	// window
	//  + vbox1
	// 	+ align1
	// 		+ draw1
	//
	// 	+ hbox1 
	// 		+ button1
	// 		+ button2
	//

} GLOBAL;

BOARD_STATE *new_board_state() {
	BOARD_STATE *bd = g_malloc0(sizeof(BOARD_STATE));
	return bd;
}

//=============================================================================
// Initialization
//=============================================================================
void init(GLOBAL *gp) {

	int i, j;

	//gp = (GLOBAL *) malloc(sizeof(GLOBAL));

	gp->hist_max = 0;
	gp->hist_cur = 0;

	gp->thread_end = false;

	// Default rendering mode
	gp->render_mode = RENDER_OGL_DIRECT;
	gp->texture = 0;

	// History
	gp->gl_history = NULL;

	gp->surface = NULL;
	gp->surface_data = NULL;

	BOARD_STATE *stat = new_board_state();
	gp->gl_history = g_list_append(gp->gl_history, stat);

}

//=============================================================================
// Rendering marble
//=============================================================================
void render_mable(cairo_t *cr, int x, int y, enum STATE state, GLOBAL *gp) {

	cairo_pattern_t *pat = NULL;

	cairo_move_to(cr, x, y);
	cairo_set_line_width(cr, 1.0);

	if (state == ST_WHITE) {
		pat = cairo_pattern_create_radial(x - 5.0, y - 5.0, 2.0, x, y, 30.0);
		cairo_pattern_add_color_stop_rgba(pat, 0, 1, 1, 1, 1);
		cairo_pattern_add_color_stop_rgba(pat, 1, 0, 0, 0, 1);
	} else if (state == ST_BLACK) {
		pat = cairo_pattern_create_radial(x - 5.0, y - 5.0, 2.0, x, y, 10.0);
		cairo_pattern_add_color_stop_rgba(pat, 0, 0.5, 0.5, 0.5, 1);
		cairo_pattern_add_color_stop_rgba(pat, 1, 0, 0, 0, 1);
	}

	cairo_set_source (cr, pat);

	cairo_arc (cr, x, y, 14.0, 0, 2 * M_PI);
	cairo_fill (cr);

	cairo_pattern_destroy (pat);
}

void render_line(cairo_t *cr, int x1, int y1, int x2, int y2, int score) {

	cairo_pattern_t *pat = NULL;
	cairo_set_line_width(cr, 10.0);

	switch(score) {
		case 6:
			pat = cairo_pattern_create_rgba(1, 0, 0, 1);break;
		case 5:
			pat = cairo_pattern_create_rgba(1, 0, 0, 0.7);break;
		case 4:
			pat = cairo_pattern_create_rgba(0, 1, 0, 0.9);break;
		case 3:
			pat = cairo_pattern_create_rgba(0, 0, 1, 0.5);break;
		default:
			pat = cairo_pattern_create_rgba(0, 0, 0, 0);break;
	}

	cairo_set_source(cr, pat);

	cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);

	cairo_move_to(cr, x1, y1);
	cairo_line_to(cr, x2, y2);

	cairo_stroke(cr);

	cairo_pattern_destroy(pat);
}

// Ʊ���������ܤ��Ƥ��ơ�����¾�ο����Ф˼��⤵��ʤ����祵����������
int get_space(GLOBAL *gp, int px, int py, int vx, int vy, int st) {

	GList *gl_stat = g_list_nth(gp->gl_history, gp->hist_cur);
	BOARD_STATE *stat = gl_stat->data;

	int sx = px;
	int sy = py;

	int cnt = 0;

	// Search forward
	while((sx >= 0) && (sx < BOARD_SIZE) && (sy >= 0) && (sy < BOARD_SIZE) && (stat->cell[sx][sy] * st >= 0) ) {
		sx += vx;
		sy += vy;
		++cnt;
	}

	sx = px - vx;
	sy = py - vy;

	// Search backward
	while((sx >= 0) && (sx < BOARD_SIZE) && (sy >= 0) && (sy < BOARD_SIZE) && (stat->cell[sx][sy] * st >= 0) ) {
		sx -= vx;
		sy -= vy;
		++cnt;
	}

	return cnt;
}


void render_connection(cairo_t *cr, GLOBAL *gp, int vx, int vy) {

	int x, y;
	GList *gl_stat = g_list_nth(gp->gl_history, gp->hist_cur);
	BOARD_STATE *stat = gl_stat->data;

	int score_h[BOARD_SIZE][BOARD_SIZE];

	// Tagging marble color
	for(y=0; y<BOARD_SIZE; ++y) {
		for(x=0; x<BOARD_SIZE; ++x) {
			int st = stat->cell[x][y];

			if( ((x-vx)<0) || ((y-vy)<0) || ((x-vx)>=BOARD_SIZE) || ((y-vy)>=BOARD_SIZE) ) {
				score_h[x][y] = st;
			} else {
				if( score_h[x-vx][y-vy] * st > 0 ) {	// if previous score cell is same color
					score_h[x][y] = score_h[x-vx][y-vy] + st;
				} else {
					score_h[x][y] = st;
				}
			}
		}
	}

	// Draw line
	for(y=0; y<BOARD_SIZE; ++y) {
		for(x=0; x<BOARD_SIZE; ++x) {
			int score = score_h[x][y];
			int a_score = abs(score);
			int st = stat->cell[x][y];

			if(a_score >= 3 && (get_space(gp, x, y, vx, vy, st) >= 6)) {
				render_line(cr, x * STEP + X_OFFSET, y * STEP + Y_OFFSET,
						(x-(a_score-1)*vx) * STEP + X_OFFSET, (y-(a_score-1)*vy) * STEP + Y_OFFSET, a_score);
			}
		}
	}   
}

//=============================================================================
// Rendering current status
//=============================================================================
void render_state(cairo_t *cr, GLOBAL *gp) {

	int x, y;
	GList *gl_stat = g_list_nth(gp->gl_history, gp->hist_cur);
	BOARD_STATE *stat = gl_stat->data;

	for (x = 0; x < BOARD_SIZE; x++) {
		for (y = 0; y < BOARD_SIZE; y++) {

			int px = x * STEP + X_OFFSET;
			int py = y * STEP + Y_OFFSET;

			switch (stat->cell[x][y]) {

				case ST_WHITE:
					render_mable(cr, px, py, ST_WHITE, gp);
					break;

				case ST_BLACK:
					render_mable(cr, px, py, ST_BLACK, gp);
					break;

				case ST_EMPTY:
				default:
					// Nothing to do
					break;
			}
		}
	}

	// Stroke
	cairo_stroke(cr);

	//render_line(cr, 10, 10, 100, 100);
	render_connection(cr, gp, 1, 0);	// Check holizontal
	render_connection(cr, gp, 0, 1);	// Check vertical
	render_connection(cr, gp, 1, 1);	// Check LUpper to RBottom
	render_connection(cr, gp, -1, 1);	// Check RUpper to LBottom
}

//=============================================================================
// Rendering Board
//=============================================================================
void render_board(cairo_t *cr, GLOBAL *gp) {

	int x, y;
	char buf[3];

	// Draw numbeArialr
	cairo_select_font_face(cr, FONT_FAMILY, CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);

	cairo_set_font_size(cr, FONT_SIZE);
	cairo_set_source_rgb(cr, RGB_FONT);

	for (x = 0; x < BOARD_SIZE; x++) {
		int tx = x * STEP + 35; 
		cairo_move_to(cr, tx, 30.0);
		sprintf(buf, "%02d", x + 1);
		cairo_show_text(cr, buf);

		cairo_move_to(cr, tx, 600.0);
		sprintf(buf, "%02d", x + 1);
		cairo_show_text(cr, buf);

	}

	for (y = 0; y < BOARD_SIZE; y++) {
		int ty = y * STEP + 45; 
		cairo_move_to(cr, 15.0, ty);
		sprintf(buf, "%02d", y + 1);
		cairo_show_text(cr, buf);

		cairo_move_to(cr, 590.0, ty);
		sprintf(buf, "%02d", y + 1);
		cairo_show_text(cr, buf);
	}

	// Draw mode label
	char *mode_str = NULL;

	cairo_set_font_size(cr, 12);
	cairo_move_to(cr, 5, 635);
	if (gp->render_mode != RENDER_SW) {
		asprintf(&mode_str, "OpenGL version: %s, %s, %s", 
				glGetString(GL_VERSION), glGetString(GL_VENDOR), glGetString(GL_RENDERER));
		cairo_show_text(cr, mode_str);
	} else {
		asprintf(&mode_str, "(Software rendering mode) Cairo version: %s", cairo_version_string());
		cairo_show_text(cr, mode_str);
	}
	free(mode_str);

	cairo_set_font_size(cr, 10);
	cairo_move_to(cr, 5, 650);
	cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
	cairo_show_text(cr, "Key 0:Default, 1:Zoom 0.5, 2:Zoom 0.8, 3:Zoom 1.5, 4:Zoom 2.0, 5:Zoom:2.5, r:Redraw, <-:Prev Hist, ->:Next Hist, SPC:Latest");
	cairo_set_font_size(cr, 9);
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	cairo_move_to(cr, 5, 665);
	cairo_show_text(cr, "GoMoKu GUI 0.1 by nyacom.net. HUNGA LAB Keio University. 2011");

	// Draw Board
	cairo_set_line_width(cr, 3.0);
	cairo_move_to(cr, STEP, STEP);
	for (x = 0; x < BOARD_SIZE - 1; x++) {
		for (y = 0; y < BOARD_SIZE - 1; y++) {

			int px = x * STEP + X_OFFSET;
			int py = y * STEP + Y_OFFSET;

			cairo_set_source_rgb(cr, RGB_CELLFILL); 
			cairo_rectangle(cr, px, py, STEP, STEP);
			cairo_fill_preserve(cr);
			cairo_set_source_rgb(cr, RGB_CELLEDGE); 
			cairo_rectangle(cr, px, py, STEP, STEP);
		}
	}

	cairo_stroke(cr);
}

//=============================================================================
// Render
//=============================================================================
void render(cairo_t *cr, GLOBAL *gp) {

	// Set blackground
	cairo_pattern_t *pat = cairo_pattern_create_linear (0.0, 0.0, 0.0, 800.0);
	cairo_pattern_add_color_stop_rgba (pat, 0, RGB_BGCOLOR0, 1);
	cairo_pattern_add_color_stop_rgba (pat, 1, RGB_BGCOLOR1, 1);
	cairo_set_source (cr, pat);
	cairo_fill (cr);

	//cairo_set_source_rgb(cr, RGB_BGCOLOR);
	cairo_paint(cr);
	cairo_stroke(cr);
	cairo_pattern_destroy (pat);

	// Scaled rendering only for software rendering mode
	if (gp->render_mode == RENDER_SW) {

		// Get size (Window)��������ɥ����礭������ˤ��Ƥ��뤿�� draw1�����ǤϤʤ�
		int width, height;
		gtk_window_get_size(GTK_WINDOW(gp->window), &width, &height);

		// Set scale
		double mag = 1.0;
		if (height < width) {
			mag = (double)height / (double)gp->default_height;
		} else if (width < height) {
			mag = (double)width / (double)gp->default_width;
		}

		cairo_scale(cr, mag, mag);
	}

	// Render board
	render_board(cr, gp);

	// Render state
	render_state(cr, gp);
}

//=============================================================================
// Show window
//=============================================================================
static gint draw1_realize(GtkWidget *widget, gpointer data) {

	GLOBAL *gp = data;

	if (gp->render_mode != RENDER_SW) {
		glMatrixMode (GL_PROJECTION);
		glLoadIdentity ();
		glOrtho (0.0f, 1.0f, 0.0f, 1.0f, -1.0f, 1.0f);	// L R B T N F
		glEnable (GL_TEXTURE_RECTANGLE_ARB);
	}

	return TRUE;
}

//=============================================================================
// Resize window
//=============================================================================
static gint draw1_configure(GtkWidget *widget, GdkEventConfigure *event, gpointer data) {

	GLOBAL *gp = data;

	if (gp->render_mode != RENDER_SW) {
		GdkGLContext *gl_context;
		GdkGLDrawable *gl_drawable;

		gboolean can_begin;

		gl_context = gtk_widget_get_gl_context(widget);
		gl_drawable = gtk_widget_get_gl_drawable(widget);

		if (gdk_gl_drawable_gl_begin(gl_drawable, gl_context)) {
			glViewport (0, 0, widget->allocation.width, widget->allocation.height);
			gdk_gl_drawable_gl_end (gl_drawable);
		}
	}

	if (gp->surface) {

		cairo_surface_destroy(gp->surface);

		// resize create cairo surface
		if (gp->render_mode != RENDER_SW) {

			gp->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 
					GL_RESOLUTION_X, GL_RESOLUTION_Y);

		} else {

			gp->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 
					widget->allocation.width, 
					widget->allocation.height);
		}

		if (cairo_surface_status(gp->surface) != CAIRO_STATUS_SUCCESS) {
			//g_assert_not_reached ();
		}

		gp->surface_data = cairo_image_surface_get_data(gp->surface);
	}

	return TRUE;
}

//=============================================================================
// Refresh window
//=============================================================================
static gint draw1_expose(GtkWidget *widget, GdkEventExpose *event, gpointer data) {

	GLOBAL *gp = data;
	cairo_t *cr = cairo_create(gp->surface);

	render(cr, gp);	// Cario rendering

	// OpenGL Renderding mode
	if (gp->render_mode != RENDER_SW) {

		GdkGLContext *gl_context;
		GdkGLDrawable *gl_drawable;
		gboolean can_begin;
		gboolean is_double_buffered;

		gl_context = gtk_widget_get_gl_context (gp->draw1);
		gl_drawable = gtk_widget_get_gl_drawable (gp->draw1);
		is_double_buffered = gdk_gl_drawable_is_double_buffered (gl_drawable);

		if (gdk_gl_drawable_gl_begin(gl_drawable, gl_context)) {

			glMatrixMode (GL_MODELVIEW);
			glLoadIdentity ();
			glClear (GL_COLOR_BUFFER_BIT);

			glBindTexture(GL_TEXTURE_RECTANGLE_ARB, gp->texture);

			glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_T, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 

			// OpenGL texture must be sized in 2^2
			glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGBA, GL_RESOLUTION_X, GL_RESOLUTION_Y,
					0, GL_BGRA, GL_UNSIGNED_BYTE, gp->surface_data);

			// Draw textured poligon
			glPushMatrix();

			glEnable(GL_TEXTURE_RECTANGLE_ARB);
			glBegin(GL_QUADS);

			//glTexCoord2d(0, gp->draw1->allocation.height);
			glTexCoord2d(0, GL_RESOLUTION_Y);
			glVertex2f(0.0f, 0.0f);			// Top left

			//glTexCoord2d(gp->draw1->allocation.width, gp->draw1->allocation.height);
			glTexCoord2d(GL_RESOLUTION_X, GL_RESOLUTION_Y);
			glVertex2f(1.0f, 0.0f);			// Top rightkeyval GTK GTK

			//glTexCoord2d(gp->draw1->allocation.width, 0);
			glTexCoord2d(GL_RESOLUTION_X, 0);
			glVertex2f(1.0f, 1.0f);			// Bottom right

			//glTexCoord2d(0, 0);
			glTexCoord2d(0, 0);
			glVertex2f(0.0f, 1.0f);			// Bottom left

			glEnd();

			glDisable(GL_TEXTURE_RECTANGLE_ARB);

			glPopMatrix();

			// OpenGL rendering
			if (is_double_buffered){
				gdk_gl_drawable_swap_buffers(gl_drawable);
			} else {
				glFlush();
			}

			gdk_gl_drawable_gl_end (gl_drawable);				// End OpenGL
		} 

	} else { // Cario + GDK drawing mode

		cairo_t *cr_wnd = gdk_cairo_create(widget->window);	// Destination
		cairo_set_source_surface(cr_wnd, gp->surface, 0.0, 0.0);
		cairo_paint(cr_wnd);
	}

	cairo_destroy(cr);

	char *buf;
	buf = g_markup_printf_escaped("step <span size='20480' weight='heavy'>%d/%d</span> latest", gp->hist_cur, gp->hist_max);
	gtk_label_set_markup(GTK_LABEL(gp->label1), buf);
	free(buf);

	return TRUE;
}

//=============================================================================
// Button1 click
//=============================================================================
void button1_click(GtkWidget *widget, gpointer data) {
	GLOBAL *gp = data;
	if (gp->hist_cur - 1 >= 0){
		gp->hist_cur--;
	}
	gtk_widget_queue_draw(gp->draw1);
}

//=============================================================================
// Button2 click
//=============================================================================
void button2_click(GtkWidget *widget, gpointer data) {
	GLOBAL *gp = data;
	if (gp->hist_cur + 1 <= gp->hist_max) {
		gp->hist_cur++;
	}
	gtk_widget_queue_draw(gp->draw1);
}

//=============================================================================
// On window key press event
//=============================================================================
void window_key_press(GtkWidget *widget, GdkEventKey *event, gpointer data) {

	GLOBAL *gp = data;

	switch(event->keyval) {

		case GDK_0:		// 0
			gtk_window_resize(GTK_WINDOW(gp->window), 
					gp->default_width, gp->default_height);
			break;

		case GDK_1:		// 1
			gtk_window_resize(GTK_WINDOW(gp->window), 
					gp->default_width * 0.5, gp->default_height * 0.5);
			break;

		case GDK_2:		// 1
			gtk_window_resize(GTK_WINDOW(gp->window), 
					gp->default_width * 0.8, gp->default_height * 0.8);
			break;

		case GDK_3:		// 3
			gtk_window_resize(GTK_WINDOW(gp->window), 
					gp->default_width * 1.5, gp->default_height * 1.5);
			break;

		case GDK_4:		// 4
			gtk_window_resize(GTK_WINDOW(gp->window),
					gp->default_width * 2, gp->default_height * 2);
			break;

		case GDK_5:		// 5
			gtk_window_resize(GTK_WINDOW(gp->window), 
					gp->default_width * 2.5, gp->default_height * 2.5);
			break;

		case GDK_Left:		// Left arrow
			button1_click(widget, gp);
			break;

		case GDK_Right:		// Right arrow
			button2_click(widget, gp);
			break;

		case GDK_space:		// Space
			gp->hist_cur = gp->hist_max;
			gtk_widget_queue_draw(gp->draw1);
			break;

		case GDK_r:		// r
			printf("hoge");
			gtk_widget_queue_draw(gp->draw1);
			break;
	}
}

//=============================================================================
// On destroy
//=============================================================================
static void destroy(GtkWidget *window, GLOBAL *gp) {
	gp->thread_end = true;
	pthread_join((pthread_t)gp->pt, NULL);
	gtk_main_quit();
}

//=============================================================================
// Thread main
//=============================================================================
void *receive_thread(void *data) {

	GLOBAL *gp = data;

	int x = 0, y = 0;
	char buf[512];

	struct timespec treq;
	treq.tv_sec = (time_t) 0;
	treq.tv_nsec = 5000;

	struct timeval timeout;
	timeout.tv_sec = 0;
	timeout.tv_usec = 0;

	BOARD_STATE *stat = new_board_state();

	fcntl(STDIN_FILENO, F_SETFL, O_NONBLOCK);

	// Polling for stdin
	while (1) {

		if (gp->thread_end) {		// If invoke thread end
			free(stat);
			return;
		}

		buf[0] = '\0';
		fgets(buf, 512, stdin);
		fputs(buf, stdout);
		fflush(stdout);

		char *st = buf, *ed = buf;
		x = 0;

		while (*ed != '\0' && *ed != '\n') {	// While not line end or new line.
			if (*ed == '|') {	// Separator is found
				*ed = '\0';
				if (x > 0) {	// If x is not first column (Row number column)
					if (strchr(st, '*') != NULL) {
						stat->cell[x-1][y] = ST_BLACK;
					} else if (strchr(st, 'o') != NULL) {
						stat->cell[x-1][y] = ST_WHITE;
					} else {
						stat->cell[x-1][y] = ST_EMPTY;
					}
				}

				x++;		// Increment column index
				st = ed+1;	// Next string start position is previous end + 1
				if (x > 19) {	// If column is reached at end of row
					y++;	// Increment row index
					if (y > 18) {	// If row number is reached at the end
						y = 0;	// Revert row number

						// If current showed (in GTK) history index is the same as max history index,
						// the current showed history index also increment.
						if (gp->hist_cur == gp->hist_max) {
							gp->hist_cur++;
						}

						gp->hist_max++;	// Update max history
						gp->gl_history = g_list_append(gp->gl_history, stat);	// Add new history

						gdk_threads_enter();			// Enter GTK thread
						gtk_widget_queue_draw(gp->draw1);
						gdk_threads_leave();			// Leave GTK thread

						stat = new_board_state();		// Prepare new board status
					}
				}
			}
			ed++;
		}

		nanosleep(&treq, NULL);
	}
}

int main(int argc, char *argv[]) {

	GLOBAL gp;

	GdkGLConfig *gl_config = NULL;
	gboolean gl_capability = false;

	init(&gp);

	// Arguments
	if (argc > 1) {
		if (strcmp(argv[1], "--safe") == 0) {
			gp.render_mode = RENDER_SW;
		}
	}

	// GDK thread init
	g_thread_init(NULL);
	gdk_threads_init();

	// GTK+ �ν���� 
	gtk_init(&argc, &argv);

	// GDK OpenGL frame buffer mode setting
	if (gp.render_mode != RENDER_SW) {
		gtk_gl_init(&argc, &argv);
		gl_config = gdk_gl_config_new_by_mode(GDK_GL_MODE_RGB | GDK_GL_MODE_DEPTH | GDK_GL_MODE_DOUBLE);

		if (!gl_config) {
			GtkWidget *msg1 = gtk_message_dialog_new(NULL, 
					GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
					"OpenGL Initialization failed. Fall back to no hardware accelerated mode.");

			gtk_window_set_title(GTK_WINDOW(msg1), "OpenGL Initialization failed");
			gtk_dialog_run(GTK_DIALOG(msg1));
			gtk_widget_destroy(msg1);

			gp.render_mode = RENDER_SW;
		}
	}

	// ������ɥ�(GtkWindow) �κ��� 
	gp.window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

	//  ������ɥ��ν������ 
	gtk_window_set_title(GTK_WINDOW(gp.window), "GoMoKu GUI for Connect6");	//  title
	gtk_window_set_default_size(GTK_WINDOW(gp.window), GL_RESOLUTION_X, GL_RESOLUTION_Y+30);	//  window size
	g_signal_connect(G_OBJECT(gp.window), "destroy", G_CALLBACK(destroy), &gp);

	// Get default window size
	gtk_window_get_size(GTK_WINDOW(gp.window), &gp.default_width, &gp.default_height);

	// Create VBox
	gp.vbox1 = gtk_vbox_new(FALSE, 1);

	// Create HButtonBox
	gp.hbox1 = gtk_hbox_new(FALSE, 0);

	// Create Buttons
	gp.button1 = gtk_button_new_with_label("< Prev");
	gp.button2 = gtk_button_new_with_label("Next >");

	// Create label
	gp.label1 = gtk_label_new("step <span size='20480' weight='heavy'>0/0 latest</span>");
	gtk_label_set_use_markup(GTK_LABEL(gp.label1), TRUE);

	// Prepareing Layout container
	gp.align1 = gtk_alignment_new(1.0, 1.0, 1.0, 1.0);

	// Create gtk drawing area
	gp.draw1 = gtk_drawing_area_new();

	if (gp.render_mode != RENDER_SW) {

		gl_capability = gtk_widget_set_gl_capability(gp.draw1, gl_config, NULL, true, GDK_GL_RGBA_TYPE);

		// Check drawing area is capable for Direct rendering of OpenGL
		if (!gl_capability) {

			GtkWidget *msg1 = gtk_message_dialog_new(NULL, 
					GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
					"OpenGL direct rendering is not capable.");

			gtk_window_set_title(GTK_WINDOW(msg1), "Warning");
			gtk_dialog_run(GTK_DIALOG(msg1));
			gtk_widget_destroy(msg1);

			gp.render_mode = RENDER_OGL_INDIRECT;

			gl_capability = gtk_widget_set_gl_capability(gp.draw1, gl_config, NULL, false, GDK_GL_RGBA_TYPE);

			if (!gl_capability) {

				msg1 = gtk_message_dialog_new(NULL, 
						GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
						"OpenGL rendering is not capable. Fall back to no hardware accelerated mode.");

				gtk_window_set_title(GTK_WINDOW(msg1), "Warning");
				gtk_dialog_run(GTK_DIALOG(msg1));
				gtk_widget_destroy(msg1);

				gp.render_mode = RENDER_SW;
			}
		}
	}


	// Create Cairo context
	if (gp.render_mode != RENDER_SW) {
		gp.surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, GL_RESOLUTION_X, GL_RESOLUTION_Y);
	} else {
		gp.surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, gp.default_height, gp.default_width);
	}

	gp.surface_data = cairo_image_surface_get_data(gp.surface);

	// Drawing area event signal connection
	gtk_signal_connect(GTK_OBJECT(gp.draw1), "realize", GTK_SIGNAL_FUNC(draw1_realize), &gp);	// First time appearance
	gtk_signal_connect(GTK_OBJECT(gp.draw1), "configure_event", GTK_SIGNAL_FUNC(draw1_configure), &gp);	// Resize
	gtk_signal_connect(GTK_OBJECT(gp.draw1), "expose_event", GTK_SIGNAL_FUNC(draw1_expose), &gp);	// Redraw
	gtk_widget_set_events(gp.draw1, GDK_EXPOSURE_MASK);

	// Window1 event signal connection
	gtk_signal_connect(GTK_OBJECT(gp.window), "key_press_event", GTK_SIGNAL_FUNC(window_key_press), &gp);	// Redraw

	// Gtk button event signal connection
	gtk_signal_connect(GTK_OBJECT(gp.button1), "clicked", GTK_SIGNAL_FUNC(button1_click), &gp);
	gtk_signal_connect(GTK_OBJECT(gp.button2), "clicked", GTK_SIGNAL_FUNC(button2_click), &gp);

	//gtk_widget_set_double_buffered(gp.draw1, false);

	// Packing container
	gtk_container_add(GTK_CONTAINER(gp.align1), gp.draw1);

	// HButtonbox packing
	gtk_box_pack_start(GTK_BOX(gp.hbox1), gp.button1, FALSE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(gp.hbox1), gp.label1, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(gp.hbox1), gp.button2, FALSE, TRUE, 0);

	// VBox packing
	gtk_box_pack_start(GTK_BOX(gp.vbox1), gp.align1, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(gp.vbox1), gp.hbox1, FALSE, FALSE, 0);

	//  �������åȤ�ᥤ�󥦥���ɥ��˥ѥå���
	gtk_container_add(GTK_CONTAINER(gp.window), gp.vbox1);

	//  ������ɥ���ɽ�� 
	gtk_widget_show_all(gp.window);

	if (gp.render_mode != RENDER_SW) {
		// Windowɽ�����Ƥ���ƤФʤ���SEG��? (GL��2�Ϥ�������פ�����)
		glGenTextures(1, &gp.texture);	
	}

	// ɸ�������Ԥ������Υ���å�����
	pthread_create(&gp.pt, NULL, &receive_thread, &gp);

	//  GTK�ᥤ��롼��
	gtk_main();

	// free GL texture
	if (gp.render_mode != RENDER_SW) {
		glDeleteTextures(1, &gp.texture);
	}

	// free cairo surface
	cairo_surface_destroy(gp.surface);

	// free History
	g_list_foreach(gp.gl_history, (GFunc)g_free, NULL);
	g_list_free(gp.gl_history);

	return 0;
}

