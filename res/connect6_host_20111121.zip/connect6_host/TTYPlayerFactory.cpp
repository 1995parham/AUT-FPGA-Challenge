#include "TTYPlayerFactory.hpp"

#include <map>
#include <string>

#include "TTYPlayer.hpp"

namespace Connect6 {

TTYPlayerFactory::TTYPlayerFactory() : IPlayerFactory() {
}

IPlayer* TTYPlayerFactory::create_
(
 const std::map<std::string, std::string>& arg,
 const std::string& name,
 const Marble& marble,
 double timeout
) {
  std::map<std::string, std::string>::const_iterator it;
  
  const std::string name_ 
    = (name.size() == 0) ? "TTYPlayer_" + marble.toString() : name;

    std::string rd_port;
  if ( (it = arg.find("readport")) != arg.end()) {
    rd_port = it->second;
  } else {
    rd_port = "/dev/stdin";
  }

  std::string wr_port;
  if ( (it = arg.find("writeport")) != arg.end()) {
    wr_port = it->second;
  } else {
    wr_port = "/dev/null";
  }

  return new TTYPlayer(rd_port, wr_port, name_, marble, timeout);

}

TTYPlayerFactory::~TTYPlayerFactory() {
}

};
