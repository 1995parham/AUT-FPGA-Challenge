#include "Placement.hpp"

#include <sstream>

#include "IPlayer.hpp"
#include "Marble.hpp"

namespace Connect6 {

Placement::Placement(const IPlayer& player, const int row, const int column) 
  : player_(&player), marble_(&(player.getMarble())), row_(row), column_(column), t_(NORMAL) {
}

Placement::Placement(Type t)
  : player_(NULL), marble_(NULL), row_(0), column_(0), t_(t) {
}

Placement::Placement(const Placement& p)
  : player_(p.player_), marble_(p.marble_), row_(p.row_), column_(p.column_), t_(p.t_) {
}

const IPlayer& Placement::getPlayer() const {
  return *player_;
}

const Marble& Placement::getMarble() const {
  return *marble_;
}

int Placement::getRow() const {
  return row_;
}

int Placement::getColumn() const {
  return column_;
}

Placement::Type Placement::getType() const {
  return t_;
}

std::string Placement::toString() const {
  std::ostringstream oss;
  oss << getPlayer().getName() << ":" 
      << getMarble().toString() << ":"
      << getRow() << ":"
      << getColumn();
  
  return oss.str();
}

Placement::~Placement() {

}

};

