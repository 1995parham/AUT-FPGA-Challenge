/**
 * modified by Keisuke Dohi 2011/08/05
 */

#ifndef ___RDTSC_H___
#define ___RDTSC_H___
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<stdint.h>
#include<sys/time.h>
#include <stdio.h>
#include <stdint.h>

#ifdef __x86_64__ 

#define RDTSC(X) \
  do { \
  __asm__ __volatile__ ("cpuid" : : : "rax", "rbx", "rcx", "rdx"); \
  __asm__ __volatile__ ( \
            "rdtsc\n\t" \
	    "shlq       $32, %%rdx\n\t"		\
	    "orq        %%rdx, %%rax\n\t"			 \
	    "movq       %%rax, %0" : "=g" (X) : : "rax", "rdx"); \
  } while (0)

#elif __i386__

#define RDTSC(X) \
  do { \
  __asm__ ("cpuid"); \
  __asm__ volatile ("rdtsc" : "=A" (X)); \
  } while (0)
  
#endif


/****  Obtain time-stamp counter (for x86 processors)  ****/
inline uint64_t get_rdtsc(void) {
  uint64_t ret;

  RDTSC(ret);
  
  return ret;
}

/****  Calculate CPU frequency by using gettimeofday() and rdtsc in x usec for n times ****/
inline double obtain_cpu_freq(unsigned long usec, int n) {
  const double MICRO_SEC_UNIT = (1/1000000.0);
  int i;
  struct timeval start_timeval, end_timeval;
  double start_time, end_time, elapsed_time;
  uint64_t start_tsc, end_tsc, cycles;
  double freq = 0.0;

  for (i=0; i<n; i++) {
    RDTSC(start_tsc);
    gettimeofday(&start_timeval, NULL);

    usleep(usec);

    RDTSC(end_tsc);
    gettimeofday(&end_timeval, NULL);
    
    start_time   = (double)(start_timeval.tv_sec) + (double)(start_timeval.tv_usec) * MICRO_SEC_UNIT;
    end_time     = (double)(end_timeval.tv_sec) + (double)(end_timeval.tv_usec) * MICRO_SEC_UNIT;
    elapsed_time = end_time - start_time;  /* sec */
    cycles       = end_tsc - start_tsc;    /* cycles */

    //printf("cycles[%d]: %ld\n", i, cycles);

    /* printf("elapsed time = %f sec, cycles = %llu, freq = %f Hz\n", elapsed_time, cycles, (double)cycles / elapsed_time); */
    freq += (double)cycles / elapsed_time;
  }

  freq = freq / (double)n;

  return freq;
}

inline double calcSecFromCycles(uint64_t start, uint64_t stop, double freq_Hz) {
  return (double)(stop - start) / freq_Hz;
}

inline void _cpuid(int op, int *eax, int *ebx, int *ecx, int *edx){
  __asm__ __volatile__ ("cpuid"                          : "=a" (*eax), "=b" (*ebx), "=c" (*ecx), "=d" (*edx)                          : "a" (op) : "cc");
}

/****  Obtain CPU name  ****/
inline char *get_cpu_name(void) {
  int eax, ebx, ecx, edx;
  static int name[12] = {0};
  _cpuid(0x80000000, &eax, &ebx, &ecx, &edx);
  if ( (eax & 0xffff) >= 4 ) {
    _cpuid(0x80000002, &name[0], &name[1], &name[ 2], &name[ 3]);
    _cpuid(0x80000003, &name[4], &name[5], &name[ 6], &name[ 7]);
    _cpuid(0x80000004, &name[8], &name[9], &name[10], &name[11]);
  }
  return (char *)name;
}

/****  Obtain frequency in MHz from CPU name (not accurate)  ****/
inline double get_cpuname_mfreq(void) {
  double freq = -1.0;
  int i, unit_size = 0;
  char name[48], buffer[8];
  strcpy(name, get_cpu_name());
  for (i = 0; i < 48-2; ++i) {
    if( name[i+1] == 'H' && name[i+2] == 'z' ) {
      if (name[i] == 'M') {
	unit_size = 1;
      } else if (name[i] == 'G') {
	unit_size = 1000;
      } else if (name[i] == 'T') {
	unit_size = 1000000;
      }
    }
    /* parse "x.xxyHz" or "xxxxyHz" */
    if (unit_size > 0) {
      strncpy(buffer, &name[i-4], 7);
      buffer[7] = 0;
      if (name[i-3] == '.') {
	freq  = (int)(name[i-4] - '0') * unit_size;
	freq += (int)(name[i-2] - '0') * (unit_size/10);
	freq += (int)(name[i-1] - '0') * (unit_size/100);
      } else {
	freq  = (int)(name[i-4] - '0') * 1000;
	freq += (int)(name[i-3] - '0') * 100;
	freq += (int)(name[i-2] - '0') * 10;
	freq += (int)(name[i-1] - '0');
	freq *= unit_size;
      }
      break;
    }
  }
  return freq;
}


#endif /*  ___RDTSC_H___ */

