#include "GameResultWin.hpp"

#include "IPlayer.hpp"

namespace Connect6 {

GameResultWin::GameResultWin(const IPlayer& player) : msg_() {
  msg_ = "Winner : " + player.getName() ;
}

std::string GameResultWin::toString_() {
  return msg_;
}

GameResultWin::~GameResultWin() {

}

};
