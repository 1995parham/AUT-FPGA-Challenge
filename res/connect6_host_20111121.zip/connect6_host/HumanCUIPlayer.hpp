#ifndef HUMANCUIPLAYER_HPP
#define HUMANCUIPLAYER_HPP

#include <string>

#include "IPlayer.hpp"
#include "Marble.hpp"

namespace Connect6 {

class Placement;

class HumanCUIPlayer : public IPlayer {

public:

  HumanCUIPlayer(const std::string& name,
		 const Marble& marble,
		 double time);
  
  void notifyMarble();
  void notifyCurrentPlayer(const IPlayer& player);
  void notifyPlacement(const Placement& placement);
  int checkPlacement();
  int getNumberOfPlacement();
  Placement* getPlacement();
  const std::string& getName() const;
  const Marble& getMarble() const;
  double getTime() const;
  
  ~HumanCUIPlayer();

private:
  const std::string name_;
  const Marble marble_;
  const double time_;
};

};

#endif
