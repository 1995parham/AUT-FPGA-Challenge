#include "GameResultTurnover.hpp"

#include <string>

namespace Connect6 {

GameResultTurnover::GameResultTurnover() {

}

GameResultTurnover::~GameResultTurnover() {

}

std::string GameResultTurnover::toString_() {
  return "Turn is over.";
}

};
