#ifndef IGAMERESULT_HPP
#define IGAMERESULT_HPP

#include <string>
#include <iostream>

namespace Connect6 {

class IGameResult {

public:
  IGameResult(){}
  
  std::string toString() {
    return toString_();
  }

  virtual ~IGameResult(){}

private:
  virtual std::string toString_() = 0;
  
};

};

#endif
