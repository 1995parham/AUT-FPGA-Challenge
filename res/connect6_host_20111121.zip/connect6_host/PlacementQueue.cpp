#include "PlacementQueue.hpp"

#include <iostream>
#include <algorithm>

#include "Options.hpp"
#include "IPlayer.hpp"
#include "Placement.hpp"
#include "RDTSCTimer.hpp"

namespace Connect6 {

void PlacementQueue::loop() {
  bool is_first_turn = true;
  bool is_timeover = false;
  
  // それぞれのプレイヤーにゲーム開始を通知
  player_current_->notifyMarble();
  player_next_->notifyMarble();

  timer_->reset();
  
  while(1) {
    pthread_testcancel();
    
    const int n_required = (is_first_turn) ? 1 : 2;

    // 値が負の時は無限に待つ
    const double timeout = player_current_->getTime();
    
    while(1) { // ビジーウェイト
      pthread_testcancel();
      
      if ( timeout >= 0 ) {
	if ( (timer_->time() >= timeout) ) break;
      } else {
	if ( player_current_->checkPlacement() >= n_required ) break;
      }
    }

    pthread_testcancel();
        
    const int n_placement = player_current_->checkPlacement();
    const int n_submit = std::min(n_placement, n_required);
    
    for(int i=0; i<n_submit; ++i) {
      Placement *p = player_current_->getPlacement();
      if(p->getType() == Placement::NORMAL) {
	push(p);
	player_next_->notifyPlacement(*p);
      } else if (p->getType() == Placement::STOP) {
	push(p);
      } else {
      }
    }
    
    // 時間切れの時はそれを通知するコマンドでキューを埋める．
    for(int i=n_submit; i<n_required; ++i) {
      push(new Placement(Placement::TIMEOVER));
      is_timeover = true;
    }

    if(is_timeover) break;
    
    timer_->reset();
    std::swap(player_current_, player_next_);
    is_first_turn = false;

  }
  
  flag_busy_ = false;
  return;
}

PlacementQueue::PlacementQueue(IPlayer *p1, IPlayer *p2)
  : player_current_(p1), player_next_(p2),
    queue_(NULL), timer_(NULL),
    flag_busy_(false){
  init();
}

void PlacementQueue::start() {
  pthread_mutex_lock(&mutex_status_);

  if(flag_busy_ == false) {
    flag_busy_ = true;
    pthread_create(&thread_, 0, &PlacementQueue::startThread, this);
  }

  pthread_mutex_unlock(&mutex_status_);
}

void PlacementQueue::finish() {
  pthread_mutex_lock(&mutex_status_);
  
  if(flag_busy_ == true) {
    pthread_cancel(thread_);
    pthread_join(thread_, NULL);
  }
  
  pthread_mutex_unlock(&mutex_status_);
}

bool PlacementQueue::empty() {
  pthread_mutex_lock(&mutex_q_);
  bool result = queue_->empty();
  pthread_mutex_unlock(&mutex_q_);
  return result;
}

size_t PlacementQueue::size() {
  pthread_mutex_lock(&mutex_q_);
  size_t s = queue_->size();
  pthread_mutex_unlock(&mutex_q_);
  return s;
}

Placement* PlacementQueue::front() {
  pthread_mutex_lock(&mutex_q_);
  Placement* p = queue_->front();
  pthread_mutex_unlock(&mutex_q_);
  return p;
}

Placement* PlacementQueue::back() {
  pthread_mutex_lock(&mutex_q_);
  Placement* p = queue_->back();
  pthread_mutex_unlock(&mutex_q_);
  return p;
}

void PlacementQueue::pop() {
 pthread_mutex_lock(&mutex_q_);
 queue_->pop();
 pthread_mutex_unlock(&mutex_q_);
}

void PlacementQueue::push(Placement* p) {
  pthread_mutex_lock(&mutex_q_);
  queue_->push(p);
  pthread_mutex_unlock(&mutex_q_);
}

void PlacementQueue::init() {
  queue_ = new std::queue<Placement*>();
  timer_ = new RDTSCTimer();

  pthread_mutex_init(&mutex_q_, NULL);
  pthread_mutex_init(&mutex_status_, NULL);
}

void* PlacementQueue::startThread(void *obj) {
  reinterpret_cast<PlacementQueue*>(obj)->loop();
  return NULL;
}

PlacementQueue::~PlacementQueue() {
  finish();
  
  pthread_mutex_destroy(&mutex_status_);
  pthread_mutex_destroy(&mutex_q_);
  
  delete timer_;
  delete queue_;
}

};
