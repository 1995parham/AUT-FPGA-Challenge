#include "Marble.hpp"

#include <string>

namespace Connect6 {

Marble::Marble(const std::string& str, char c, int i) 
  : str_(str), c_(c), i_(i) {

}

const std::string& Marble::toString() const {
  return str_;
}

char Marble::toChar() const {
  return c_;
}

int Marble::toInteger() const {
  return i_;
}

DiskColor Marble::toDiskColor() const {
  if (toInteger() == black) {
    return black;
  } else if (toInteger() == white) {
    return white;
  } else {
    return empty;
  }
}

bool Marble::operator==(const Marble& m) const {
  if( i_ == m.toInteger() ) {
    return true;
  } else {
    return false;
  }
};

bool Marble::operator!=(const Marble& m) const {
  return !(*this == m);
}

};

