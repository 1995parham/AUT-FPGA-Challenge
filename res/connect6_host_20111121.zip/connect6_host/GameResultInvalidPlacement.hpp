#ifndef GAMERESULTINVALIDPLACEMENT_HPP
#define GAMERESULTINVALIDPLACEMENT_HPP

#include "IGameResult.hpp"

#include <string>

namespace Connect6 {

class IPlayer;
class Placement;

class GameResultInvalidPlacement : public IGameResult {

public:
  GameResultInvalidPlacement(const IPlayer& player, const Placement& p, int turn);

  ~GameResultInvalidPlacement();

private:
  std::string msg_;

  std::string toString_();

};

};

#endif
