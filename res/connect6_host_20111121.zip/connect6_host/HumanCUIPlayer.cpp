#include "HumanCUIPlayer.hpp"

#include <iostream>
#include <climits>

#include "Placement.hpp"

namespace Connect6 {

HumanCUIPlayer::HumanCUIPlayer(const std::string& name,
			       const Marble& marble,
			       double time) 
  : name_(name), marble_(marble), time_(time)
{

}

void HumanCUIPlayer::notifyMarble() {
  std::cout << name_ << ":"
	    << "Your marble is " << marble_.toString() << std::endl;
};

void HumanCUIPlayer::notifyCurrentPlayer(const IPlayer& player) {
  std::cout << name_ << ":"
	    << "Current player is " << player.getName() << std::endl;
}

void HumanCUIPlayer::notifyPlacement(const Placement& placement) {
  std::cout << name_ << ":"
	    << "Placement " << placement.toString() << std::endl;
}

int HumanCUIPlayer::checkPlacement() {
  return INT_MAX;
}

int HumanCUIPlayer::getNumberOfPlacement() {
  return INT_MAX;
}

Placement* HumanCUIPlayer::getPlacement() {
  std::cout << name_ << ":"
	    << "Where? (row column)" << std::endl;

  int row, column;

  std::cin >> row >> column;

  return new Placement(*this, row, column);
}

const std::string& HumanCUIPlayer::getName() const {
  return name_;
}

const Marble& HumanCUIPlayer::getMarble() const {
  return marble_;
}

double HumanCUIPlayer::getTime() const {
  return time_;
}

HumanCUIPlayer::~HumanCUIPlayer() {
}  

};
