#include "TTYPlayer.hpp"

#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <termios.h> 

#include "IPlayer.hpp"
#include "Marble.hpp"
#include "Placement.hpp"
#include "Options.hpp"

namespace Connect6 {

TTYPlayer::TTYPlayer(const std::string& read_port, 
		     const std::string& write_port,
		     const std::string& name,
		     const Marble& marble,
		     double time)
  : fd_rd_(0), fd_wr_(1), buf_(),
    placement_queue_(), placement_log_(),
    name_(name), marble_(marble),
    time_(time) {
  
  setupTTY(read_port, write_port, &fd_rd_, &fd_wr_);
}

void TTYPlayer::notifyMarble() {
  char id = marble_.toChar();
  write(fd_wr_, &id, 1);
}

void TTYPlayer::notifyCurrentPlayer(const IPlayer& player) {
}

void TTYPlayer::notifyPlacement(const Placement& placement) {
  std::ostringstream oss;

  oss << std::setw(2) << std::setfill('0') << placement.getRow() 
      << std::setw(2) << std::setfill('0') << placement.getColumn();
  write(fd_wr_, oss.str().c_str(), 4);
  
}

int TTYPlayer::checkPlacement() {
  Placement *p = NULL;
  int row, column;

  bool flag_break = false;

  getRawData();
  
  do {

    if ( buf_[0] == 'S' ) {
      p = new Placement(Placement::STOP);
      placement_queue_.push(p);
      buf_.erase(0, 1);
      flag_break = false;
    } else if (buf_.size() >= 4) {
      std::istringstream iss( buf_.substr(0, 4) );
      iss >> row;
      column = row % 100;
      row /= 100;

      p = new Placement(*this, row, column);
      placement_queue_.push(p);
      
      buf_.erase(0, 4);
      flag_break = false;
    } else {
      flag_break = true;
    }
    
  } while (flag_break == false);

  return getNumberOfPlacement();

}

int TTYPlayer::getNumberOfPlacement() {
  return placement_queue_.size();
}

Placement* TTYPlayer::getPlacement() {
  if( getNumberOfPlacement() > 0) {
    Placement *p = placement_queue_.front();
    placement_queue_.pop();
    placement_log_.push_back(p);
    return p;
  } else {
    return NULL;
  }
}

const std::string& TTYPlayer::getName() const {
  return name_;
}

const Marble& TTYPlayer::getMarble() const {
  return marble_;
}

double TTYPlayer::getTime() const {
  return time_;
}

int TTYPlayer::getReadFd() const {
  return fd_rd_;
}

int TTYPlayer::getWriteFd() const {
  return fd_wr_;
}

int TTYPlayer::getRawData() {
  char buf[128];
  
  // fd_rd��non-blocking�Ǥ��뤳�Ȥ�����Υ�����
  size_t size = read(fd_rd_, buf, sizeof(buf));
  for(size_t i=0; i<size; ++i) {
    buf_ += buf[i];
  }

  return buf_.size();
}

void TTYPlayer::setupTTY( const std::string& read_port,
			  const std::string& write_port,
			  int *read_fd,
			  int *write_fd
) {
  // read��write��Ʊ���ݡ��Ȥˤ��뤫�ɤ����ǥ��ץ�����Ѥ��
  if (read_port == write_port) {
    int opt = Connect6::Options::instance()->getPortOpenOption();
    *read_fd = *write_fd = openTTY(read_port, opt);
  } else {
    int opt_rd = Connect6::Options::instance()->getReadPortOpenOption();
    *read_fd = openTTY(read_port, opt_rd);
    int opt_wr = Connect6::Options::instance()->getWritePortOpenOption();
    *write_fd = openTTY(write_port, opt_wr);
  }

}

int TTYPlayer::openTTY(const std::string& port, int open_opt) {
  int permiss = ((open_opt & O_WRONLY)!= 0) ? (S_IREAD | S_IWRITE) : 0;
  int port_fd = open(port.c_str(), open_opt, permiss);
  
  while( port_fd < 0) {  
    std::string new_port = port;
    
    std::cout << "Unable to open port "
	      <<  new_port
	      << " for " << name_
	      << ", try again, should be: (windows) /dev/comx or (linux) /dev/ttyx ?"
	      << std::endl;
    
    std::cin >> new_port;
    port_fd = open(new_port.c_str(), open_opt, permiss);
  }
  
  // ���ꥢ��ݡ��Ȥ�����

  struct termios newtio;
  memset(&newtio, 0,sizeof(newtio));

  newtio.c_cflag= (B115200 | CS8 | CLOCAL | CREAD);
   
  newtio.c_iflag=IGNPAR;         
  newtio.c_oflag=0;              
  newtio.c_lflag=0;              

  tcflush(port_fd,TCIFLUSH);           /* �ݡ��ȤΥ��ꥢ */
  tcsetattr(port_fd, TCSANOW, &newtio);
  
  return port_fd;  
}

TTYPlayer::~TTYPlayer() {
  if (fd_rd_ == fd_wr_) {
    close(fd_rd_);
  } else {
    if (fd_rd_ != 0) close(fd_rd_);
    if (fd_wr_ != 1) close(fd_wr_);
  }
}

};
