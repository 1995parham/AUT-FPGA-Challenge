#include "GameResultInvalidPlacement.hpp"

#include <string>
#include <sstream>

#include "IPlayer.hpp"
#include "Placement.hpp"

namespace Connect6 {

GameResultInvalidPlacement::GameResultInvalidPlacement
(
 const IPlayer& player, const Placement& p, int turn
) : msg_() {
  std::ostringstream oss;
  oss << "ERROR! Invalid placement."
      << "Turn:" << turn 
      << ", Player:" << player.getName()
      << ", Placement:" << p.getColumn()
      << "," << p.getRow();

  msg_ = oss.str();
  
}

GameResultInvalidPlacement::~GameResultInvalidPlacement() {
}

std::string GameResultInvalidPlacement::toString_(){
  return msg_;
}

};
