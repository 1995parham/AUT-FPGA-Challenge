#include "Options.hpp"

#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include <sstream>

namespace Connect6 {

Options* Options::impl_ = NULL;

Options* Options::instance() {
  if( impl_ == NULL) {
    impl_ = new Options();
  }

  return impl_;
}

Options::Options()
  : timeout_(DEFAULT_TIMEOUT),
    port_open_option_(DEFAULT_PORT_OPEN_OPTION), 
    port_rd_open_option_(DEFAULT_READ_PORT_OPEN_OPTION),
    port_wr_open_option_(DEFAULT_WRITE_PORT_OPEN_OPTION),
    players_info_(),
    board_size_(DEFAULT_BOARDSIZE)
{
}

void Options::setArgs(int argc, char *argv[]) {
 
  //* -port���ץ����ʣ�����Ϥ����Τǡ��Ȥꤢ����������¸���Ƥ����ơ���Ƭ����Ĥ�Ȥ���
  
  --argc; ++argv;
  
  for( int i=0; i<argc; ++i ) {
    const std::string opt_name  = std::string(argv[i]);
    if (
	opt_name == "-port" ||
	opt_name == "-p"
    ) {
      if ((i+1) == argc) {
	std::cerr << "ERROR! '"
		  << opt_name 
		  << "' option needs arguments. Last '"
		  << opt_name 
		  << "' option will be ignored." 
		  << std::endl;
      } else {
	std::string info = "tty::"+toString(timeout_)+":"+std::string(argv[i+1]);
	players_info_.push_back(info);
	++i;
      }
    } else if (opt_name == "-h"
	       || opt_name == "-human") {
      if ((i+1) == argc) {
	std::cerr << "ERROR! '"
		  << opt_name 
		  << "' option needs arguments. Last '"
		  << opt_name 
		  << "' option will be ignored." 
		  << std::endl;
      } else {
	std::string info = "humancui:"+std::string(argv[i+1])+":-1";
	players_info_.push_back(info);
	++i;
      }
    } else if (opt_name == "-t") {
      if ((i+1) == argc) {
	std::cerr << "ERROR! '" 
		  << opt_name 
		  << "' option needs arguments. Last '"
		  << opt_name
		  << "' option will be ignored." 
		  << std::endl;
      } else {
	timeout_ = toInteger(std::string(argv[i+1]));
	++i;
      }
    }
  }
}

int Options::sizePlayersInfo() const {
  return players_info_.size();
}

std::string Options::getPlayersInfo(int n) const {
  if(n >= sizePlayersInfo()) {
    return std::string();
  } else {
    return players_info_.at(n);
  }    
}

int Options::getPortOpenOption() const {
  return port_open_option_;
}

int Options::getReadPortOpenOption() const {
  return port_rd_open_option_;
}

int Options::getWritePortOpenOption() const {
  return port_wr_open_option_;
}

int Options::getTimeout() const {
  return timeout_;
}

int Options::getBoardSize() const {
  return board_size_;
}

int Options::getTotalTurn() const {
  int s = getBoardSize();
  return ( (s*s)-1 ) / 2 + 1;
}

int Options::toInteger(const std::string& str) {
  std::istringstream iss(str);
  int value;
  iss >> value;
  return value;
}

std::string Options::toString(const int i) {
  std::ostringstream oss;

  oss << i;
  return oss.str();
}


void Options::printUsage(std::ostream& ost) const {
  
  ost << "* Usage of Connect6 host program *" << std::endl;
  ost << std::endl;
  ost << "Options:" << std::endl;
  ost << " -port port[:port]        : Specify port for both input and output." << std::endl;
  ost << "                            -port /dev/tty0 : Specify /dev/tty0 as input and output port." << std::endl;
  ost << "                            -port /dev/tty0:/dev/null : Specify /dev/tty0 as input port and /dev/null as output port" << std::endl;
  ost << std::endl;
  ost << " -t time                  : Specify the time per one turn for the port players" << std::endl;
  ost << "                            -t 3 : Player has 3 seconds to complete a move." << std::endl;
  ost << std::endl;
  ost << " -human name              : Specify a player as human with CUI." << std::endl;
  ost << std::endl;
  ost << "Example: " << std::endl;
  ost << "connect6 -t 4 -port /dev/tty0:/dev/null -human taro " << std::endl;

}

//  if (*port_read == "-") *port_read = "/dev/stdin";
//  if (*port_write == "-") *port_write = "/dev/stdout";

Options::~Options() {
}

};
