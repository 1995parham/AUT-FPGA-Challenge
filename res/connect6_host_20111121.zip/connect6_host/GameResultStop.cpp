#include "GameResultStop.hpp"

#include <string>

#include "IPlayer.hpp"

namespace Connect6 {

GameResultStop::GameResultStop(const IPlayer& player) : msg_() {
  msg_ = player.getName() + " submitted the STOP signal.";
}

GameResultStop::~GameResultStop() {
}

std::string GameResultStop::toString_() {
  return msg_;
}

};
