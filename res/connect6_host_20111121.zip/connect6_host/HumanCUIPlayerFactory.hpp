#ifndef HUMANCUIPLAYERFACTORY_HPP
#define HUMANCUIPLAYERFACTORY_HPP

#include "IPlayerFactory.hpp"

namespace Connect6 {

class HumanCUIPlayerFactory : public IPlayerFactory {

public:
  HumanCUIPlayerFactory();
  
  ~HumanCUIPlayerFactory();

protected:
  IPlayer* create_(const std::map<std::string, std::string>& arg,
		   const std::string& name,
		   const Marble& marble,
		   double timeout);
};

};

#endif
