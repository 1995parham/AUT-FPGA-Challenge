#ifndef GAMERESULTSTOP_HPP
#define GAMERESULTSTOP_HPP

#include "IGameResult.hpp"

#include <string>

namespace Connect6 {

class IPlayer;

class GameResultStop : public IGameResult {
public:
  GameResultStop(const IPlayer& player);

  ~GameResultStop();

private:
  std::string msg_;
  std::string toString_();
};

};

#endif
